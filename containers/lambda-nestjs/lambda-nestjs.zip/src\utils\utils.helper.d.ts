export declare class Utils {
    dtoValidationErrorMessage(issues: any): string;
}
