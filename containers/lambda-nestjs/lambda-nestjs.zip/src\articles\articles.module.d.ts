export declare class ArticlesModule {
}
