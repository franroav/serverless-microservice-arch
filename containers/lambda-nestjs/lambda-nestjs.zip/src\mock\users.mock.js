const user = {
    internalCode: 200,
    message: 'ok',
    payload: [
        {
            _id: '638d2979c8d21a9f09e1f71d',
            email: 'franroav@gmail.com',
            password: 'prueba1',
            __v: 0,
        },
        {
            _id: '638ea9b68b1f6bc07f6adb67',
            email: 'webkonce@gmail.com',
            password: '$2b$10$uwkf/5wtKfpdBbxMSSePje5eL/owosUhCYHi6EJpU7TJ.DDb35wtO',
            __v: 0,
        },
    ],
};
//# sourceMappingURL=users.mock.js.map