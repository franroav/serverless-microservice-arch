const subscriber = [
    {
        name: 'Francisco Roa Valenzuela',
        email: 'franroav@gmail.com',
        address: 'Froilan Lagos 591',
        gender: 'Hombre',
        invitation: 10,
        amount: 55000,
        code: '74Fs34',
        created_at: '2022-04-25T12:05:53-04:00',
        updated_at: '2022-04-25T12:05:53-04:00',
        traces: [
            { email: 'webkonce@gmail.com', name: 'Francisco Roa' },
        ]
    },
    {
        email: 'palindroma@gmail.com',
        name: 'Palindromas',
        gender: 'Hombre',
        address: 'Catalina de Erauzo 283',
        code: 'h1PXSS',
        invitation: 1,
        amount: 5000,
        created_at: '2022-04-27T19:35:14-04:00',
        updated_at: '2022-04-27T19:35:14-04:00',
        traces: [],
    }
];
//# sourceMappingURL=subcriptions.mock.js.map