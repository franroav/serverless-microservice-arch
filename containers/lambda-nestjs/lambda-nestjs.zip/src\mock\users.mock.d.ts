declare const user: {
    internalCode: number;
    message: string;
    payload: {
        _id: string;
        email: string;
        password: string;
        __v: number;
    }[];
};
