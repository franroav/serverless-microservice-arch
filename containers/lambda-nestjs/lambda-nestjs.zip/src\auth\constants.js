"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.jwtConstants = void 0;
exports.jwtConstants = {
    secret: process.env.SECRET_KEY,
};
//# sourceMappingURL=constants.js.map