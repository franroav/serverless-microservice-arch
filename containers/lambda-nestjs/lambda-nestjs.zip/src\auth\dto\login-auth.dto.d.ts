export declare class LoginAuthDto {
    email: string;
    password: string;
}
